//
// ====================================================================
// Copyright (c) 2003-2007 Barry A Scott.  All rights reserved.
//
// This software is licensed as described in the file LICENSE.txt,
// which you should have received as part of this distribution.
//
// ====================================================================
//
//
//	pysvn_version.hpp.template
//
#ifndef __PYSVN_VERSION_HPP__
#define __PYSVN_VERSION_HPP__
const int version_major( 1 );
const int version_minor( 9 );
const int version_patch( 3 );
const int version_build( 0 );
#endif
