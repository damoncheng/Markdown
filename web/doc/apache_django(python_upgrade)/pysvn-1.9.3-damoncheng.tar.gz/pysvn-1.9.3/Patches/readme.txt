This directory contains any patches that need to be applied to 3rd party code
to allow pysvn to build.

