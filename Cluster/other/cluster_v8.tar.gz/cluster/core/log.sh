#!/bin/bash

log=$1
data=$2

echo "$data" >> ${log}
exit 0
